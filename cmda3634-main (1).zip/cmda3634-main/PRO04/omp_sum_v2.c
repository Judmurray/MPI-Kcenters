#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define PAD_SIZE 128

typedef struct sum_bb_thread_s {
    long long int sum;
    int pad[PAD_SIZE];
} sum_bb_thread_type;

int main(int argc, char **argv) {

    /* get N and num_threads from command line */
    if (argc != 3) {
	printf ("Command usage : %s %s %s\n",argv[0],"N","num_threads");
	return 1;
    }

    long long int N = atol(argv[1]);
    int num_threads = atoi(argv[2]);
    omp_set_num_threads(num_threads);
    long long int sum = 0;
    sum_bb_thread_type sum_bb[num_threads];

    /* start the timer */
    double start_time, end_time;
    start_time = omp_get_wtime();

#pragma omp parallel default(none) shared(N,num_threads,sum_bb)
    {
	int thread_num = omp_get_thread_num();
	sum_bb[thread_num].sum = 0;
	for (long long int i = 1+thread_num; i <= N;i+=num_threads) {
	    sum_bb[thread_num].sum += i;
	}
    }
    
    for (int i=0;i<num_threads;i++) {
        sum += sum_bb[i].sum;
    }    

    /* stop the timer */
    end_time = omp_get_wtime();

#ifdef DEBUG
    printf ("number of threads = %d\n",num_threads);
    printf ("pad size = %d\n",PAD_SIZE);
    printf ("sum = %ld\n",sum);
    printf ("N*(N+1)/2 = %ld\n",(N/2)*(N+1));
    printf ("wall time used = %.4f sec\n",(end_time-start_time));
#else
    printf ("(%d,%.4f),",num_threads,(end_time-start_time));
#endif
}
