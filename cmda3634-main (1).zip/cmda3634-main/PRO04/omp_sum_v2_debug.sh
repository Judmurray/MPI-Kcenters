#!/bin/bash
#SBATCH -A cmda3634_rjh
#SBATCH -p normal_q
#SBATCH -t 00:10:00
#SBATCH --cpus-per-task=4
#SBATCH -o omp_sum_v2_debug.out

# Go to the directory where the job was submitted
cd $SLURM_SUBMIT_DIR

# Load the modules
module load matplotlib

# Build the executable
gcc -D DEBUG -o omp_sum_v2 omp_sum_v2.c -fopenmp

# OpenMP settings
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export OMP_PROC_BIND=TRUE
export OMP_DYNAMIC=FALSE
export OMP_PLACES=cores

# run omp_sum
./omp_sum_v2 100000000 1
./omp_sum_v2 100000000 2
./omp_sum_v2 100000000 4

# The script will exit whether we give the "exit" command or not.
exit
