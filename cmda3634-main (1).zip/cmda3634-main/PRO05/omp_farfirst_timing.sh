#!/bin/bash
#SBATCH -A cmda3634_rjh
#SBATCH -p normal_q
#SBATCH -t 00:10:00
#SBATCH --cpus-per-task=128
#SBATCH -o omp_farfirst_timing.out
#SBATCH --exclusive

# Go to the directory where the job was submitted
cd $SLURM_SUBMIT_DIR

# Load the modules
module load matplotlib

# Build the executable
gcc -o omp_kmeans omp_kmeans.c mat.c vec.c -fopenmp

# OpenMP settings
export OMP_NUM_THREADS=$SLURM_CPUS_PER_TASK
export OMP_PROC_BIND=spread
export OMP_PLACES=cores
export OMP_DYNAMIC=FALSE

# run omp_farfirst
./omp_kmeans 25 0 1
./omp_kmeans 25 0 2
./omp_kmeans 25 0 4
./omp_kmeans 25 0 8
./omp_kmeans 25 0 16
./omp_kmeans 25 0 32
./omp_kmeans 25 0 64
./omp_kmeans 25 0 128

# The script will exit whether we give the "exit" command or not.
exit
