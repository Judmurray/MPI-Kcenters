#include <stdio.h>
#include <stdlib.h>
#include "mat.h"

void mat_init (mat_type* A, double* data, int rows, int cols) {
    A->data = data;
    A->rows = rows;
    A->cols = cols;
}

void mat_malloc (mat_type* A, int rows, int cols) {
    A->data = (double*)malloc(rows*cols*sizeof(double));
    A->rows = rows;
    A->cols = cols;
}

void mat_calloc (mat_type* A, int rows, int cols) {
    A->data = (double*)calloc(rows*cols,sizeof(double));
    A->rows = rows;
    A->cols = cols;
}

void mat_free (mat_type* A) {
    free (A->data);
    A->data = 0;
    A->rows = 0;
    A->cols = 0;
}

/* get a pointer to the i^th row vector of A */
void mat_get_row (mat_type* A, vec_type* row, int i) {
    row->dim = A->cols;
    row->data = A->data+i*A->cols;
}

void mat_print (mat_type* A) {
    vec_type row;
    for (int i=0;i<A->rows;i++) {
	mat_get_row(A,&row,i);
	vec_print(&row);
    }
}

/* reads a matrix from STDIN */
/* returns how many rows read */
int mat_read (mat_type* A) {
    int num_read = 0;
    vec_type row;
    for (int i=0;i<A->rows;i++) {
	mat_get_row(A,&row,i);
	if (vec_read(&row) == A->cols) {
	    num_read += 1;
	}
    }
}

typedef unsigned char byte;

/* read a matrix from a binary file of unsigned chars */
void matrix_read_bin (mat_type* A, char* filename, int header_size) {

    byte header[header_size];
    FILE* fptr;

    /* open the binary file for reading */
    fptr = fopen(filename,"rb"); 

    /* need to check for null */
    if (fptr == 0) {
	printf ("Error opening binary data file.\n");
	exit(1);
    }

    /* allocate space for the data buffer */
    int data_size = A->rows*A->cols;
    byte* data = (byte*)malloc(data_size*sizeof(byte));
    if (data == 0) {
	printf ("Error allocating buffer to read data file.\n");
	exit(1);
    }

    /* skip over header */
    size_t num_read = 0;
    num_read = fread(header, sizeof(byte), header_size, fptr);

    /* read data */
    num_read = fread(data, sizeof(byte), data_size, fptr);

    /* store data in the given matrix */
    for (int i=0;i<A->rows;i++) {
	for (int j=0;j<A->cols;j++) {
	    A->data[i*A->cols+j] = (double)data[i*A->cols+j];
	}
    }

    /* free the data buffer */
    free (data);

    /* close the binary file */
    fclose(fptr);
}

/* performs the deep copy A->data = B->data */
void mat_copy (mat_type* A, mat_type* B) {
    for (int i=0;i<A->rows*A->cols;i++) {
	A->data[i] = B->data[i];
    }
}

/* zeros the matrix A */
void mat_zero (mat_type* A) {
    for (int i=0;i<A->rows*A->cols;i++) {
	A->data[i] = 0;
    }
}

void mat_add (mat_type* A, mat_type* B, mat_type* C) {
    for (int i=0;i<A->rows*A->cols;i++) {
	C->data[i] = A->data[i] + B->data[i];
    }
}
