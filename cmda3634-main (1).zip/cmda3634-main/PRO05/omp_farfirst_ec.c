#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <omp.h>
#include "mat.h"

/* calculate the center cost and arg max */
double center_cost (mat_type* dataset, int* centers, int i, int* arg_max, vec_type* dists_sq) {
    double cost = 0;
    vec_type row_j, row_center;
    mat_get_row(dataset,&row_center,centers[i-1]);
    for (int j=0;j<dataset->rows;j++) {
	mat_get_row(dataset,&row_j,j);
	double dist_sq = vec_dist_sq(&row_j,&row_center);
	if (dist_sq < dists_sq->data[j]) {
	    dists_sq->data[j] = dist_sq;
	}
	if (dists_sq->data[j] > cost) {
	    cost = dists_sq->data[j];
	    *arg_max = j;
	}
    }
    return cost;
}

int main (int argc, char** argv) {

    /* get k and num_threads from command line */
    if (argc < 3) {
	printf ("Command usage : %s %s\n",argv[0],"k","num_threads");
	return 1;
    }

    int k = atoi(argv[1]);
    int num_threads = atoi(argv[2]);
    omp_set_num_threads(num_threads);

    mat_type dataset;

    /* start the timer */
    double start_time, end_time;
    start_time = omp_get_wtime();

    /* read in the mnist training set of 60000 images */
    int rows = 60000;
    int cols = 784;
    mat_malloc (&dataset,rows,cols);
    matrix_read_bin(&dataset,"train-images-idx3-ubyte",16);

    /* find k centers using the farthest first algorithm */
    int centers[k];
    double cost;
    int arg_max;
    centers[0] = 0;
    vec_type dists_sq;
    vec_malloc(&dists_sq,dataset.rows);
    for (int i=0;i<dataset.rows;i++) {
	dists_sq.data[i] = DBL_MAX;
    }
    for (int i=1;i<k;i++) {
	cost = center_cost(&dataset,centers,i,&arg_max,&dists_sq);
	centers[i] = arg_max;
    }

    /* calculate the cost of the k centers */
    cost = center_cost(&dataset,centers,k,&arg_max,&dists_sq);

    /* stop the timer */
    end_time = omp_get_wtime();

#ifdef DEBUG
    /* print the wall time used as a comment */
    printf ("# wall time used = %g sec\n",end_time-start_time);
    /* print the approximate minimal cost for the k-center problem */
    printf ("# approximate optimal cost = %0.2f\n",cost);
    /* print an approx optimal solution to the k-center problem */
    printf ("# approx optimal centers : \n");
    for (int i=0;i<k;i++) {
	vec_type row_i;
	mat_get_row (&dataset, &row_i, centers[i]);
	vec_print (&row_i);
    }
#else
    printf ("(%d,%.4f),",num_threads,(end_time-start_time));
#endif

    /* free the matrices */
    mat_free(&dataset);
    vec_free(&dists_sq);

    return 0;

}
