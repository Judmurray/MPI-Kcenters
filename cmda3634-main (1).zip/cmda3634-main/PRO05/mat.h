#ifndef MAT_H
#define MAT_H

#include "vec.h"

typedef struct mat_s {
    double* data;
    int rows;
    int cols;
} mat_type;

void mat_init (mat_type* A, double* data, int rows, int cols);

void mat_malloc (mat_type* A, int rows, int cols);

void mat_calloc (mat_type* A, int rows, int cols);

void mat_free (mat_type* A);

/* get a pointer to the i^th row vector of A */
void mat_get_row (mat_type* A, vec_type* row, int i);

void mat_print (mat_type* A);

/* reads a matrix from STDIN */
/* returns how many rows read */
int mat_read (mat_type* A);

/* read a matrix from a binary file of unsigned chars */
void matrix_read_bin (mat_type* A, char* filename, int header_size);

/* performs the deep copy A->data = B->data */
void mat_copy (mat_type* A, mat_type* B);

/* zeros the matrix A */
void mat_zero (mat_type* A);

/* C = A + B */
void mat_add (mat_type* A, mat_type* B, mat_type* C);

#endif
