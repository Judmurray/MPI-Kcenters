#!/bin/bash
#SBATCH -A cmda3634_rjh
#SBATCH -p normal_q
#SBATCH -t 00:10:00
#SBATCH --cpus-per-task=128
#SBATCH -o omp_extreme_timing.out
#SBATCH --exclusive

# Go to the directory where the job was submitted
cd $SLURM_SUBMIT_DIR

# Load the modules
module load matplotlib

# Build the executable
gcc -o omp_extreme omp_extreme.c mat.c vec.c -fopenmp -lm

# OpenMP settings
export OMP_PROC_BIND=true
export OMP_DYNAMIC=false

# run omp_extreme
cat mnist_test5k.dat | ./omp_extreme 1
cat mnist_test5k.dat | ./omp_extreme 2
cat mnist_test5k.dat | ./omp_extreme 4
cat mnist_test5k.dat | ./omp_extreme 8
cat mnist_test5k.dat | ./omp_extreme 16
cat mnist_test5k.dat | ./omp_extreme 32
cat mnist_test5k.dat | ./omp_extreme 64
cat mnist_test5k.dat | ./omp_extreme 128

# The script will exit whether we give the "exit" command or not.
exit
