#ifndef MAT_H
#define MAT_H

#include "vec.h"

typedef struct mat_s {
    double* data;
    int rows;
    int cols;
} mat_type;

void mat_malloc (mat_type* A, int rows, int cols);

void mat_calloc (mat_type* A, int rows, int cols);

void mat_free (mat_type* A);

/* get a pointer to the i^th row vector of A */
void mat_get_row (mat_type* A, vec_type* row, int i);

void mat_print (mat_type* A, char* name);

/* reads a matrix from STDIN */
/* returns how many rows read */
int mat_read (mat_type* A);

#endif
