#!/bin/bash
#SBATCH -A cmda3634_rjh
#SBATCH -p normal_q
#SBATCH -t 00:10:00
#SBATCH --cpus-per-task=4
#SBATCH -o omp_extreme_debug.out

# Go to the directory where the job was submitted
cd $SLURM_SUBMIT_DIR

# Load the modules
module load matplotlib

# Build the executable with the DEBUG flag set
gcc -D DEBUG -o omp_extreme omp_extreme.c mat.c vec.c -fopenmp -lm

# OpenMP settings
export OMP_PROC_BIND=true
export OMP_DYNAMIC=false

# run omp_extreme
cat mnist_test1k.dat | ./omp_extreme 1
cat mnist_test1k.dat | ./omp_extreme 2
cat mnist_test1k.dat | ./omp_extreme 4

# The script will exit whether we give the "exit" command or not.
exit
