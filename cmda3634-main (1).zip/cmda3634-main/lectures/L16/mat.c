#include <stdio.h>
#include <stdlib.h>
#include "mat.h"

void mat_malloc (mat_type* A, int rows, int cols) {
    A->data = (double*)malloc(rows*cols*sizeof(double));
    A->rows = rows;
    A->cols = cols;
}

void mat_calloc (mat_type* A, int rows, int cols) {
    A->data = (double*)calloc(rows*cols,sizeof(double));
    A->rows = rows;
    A->cols = cols;
}

void mat_free (mat_type* A) {
    free (A->data);
    A->data = 0;
    A->rows = 0;
    A->cols = 0;
}

/* get a pointer to the i^th row vector of A */
void mat_get_row (mat_type* A, vec_type* row, int i) {
    row->dim = A->cols;
    row->data = A->data+i*A->cols;
}

void mat_print (mat_type* A, char* name) {
    printf ("The %d x %d matrix %s:\n",A->rows,A->cols,name);
    char row_name[BUFSIZ];
    vec_type row;
    for (int i=0;i<A->rows;i++) {
	mat_get_row(A,&row,i);
	sprintf (row_name,"row %d",i);
	vec_print(&row,row_name);
    }
}

/* reads a matrix from STDIN */
/* returns how many rows read */
int mat_read (mat_type* A) {
    int num_read = 0;
    vec_type row;
    for (int i=0;i<A->rows;i++) {
	mat_get_row(A,&row,i);
	if (vec_read(&row) == A->cols) {
	    num_read += 1;
	}
    }
}
