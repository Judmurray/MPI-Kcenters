#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#include "mat.h"

int main (int argc, char** argv) {

    /* get number of threads from command line (optional argument) */
    int num_threads = 1;
    if (argc == 2) {
	num_threads = atoi(argv[1]);
    }
    omp_set_num_threads(num_threads);


    mat_type dataset;
    int rows, cols;

    /* start the timer */
    double start_time, end_time;
    start_time = omp_get_wtime();

    /* read the shape of the matrix from STDIN */
    if (scanf("%d %d",&rows,&cols) != 2) {
	printf ("error reading the shape of the matrix\n");
	return 1;
    }

    /* allocate memory for the (rows x cols) dataset */
    mat_malloc (&dataset,rows,cols);

    /* read the dataset from STDIN */
    mat_read (&dataset);

    double max_dist_sq = 0;
    int extreme1, extreme2;
    vec_type row1, row2;

    double max_dist_sq_bb[num_threads];
    int extreme1_bb[num_threads];
    int extreme2_bb[num_threads];

#pragma omp parallel defab
 {
    vec_type row1, row2; 
    double max_dist_sq_thread = 0;
    int extreme1_thread, extreme2_thread; 
    int thread_num = omp_get_thread_num(); 
    for (int i=0+thread_num;i<dataset.rows-1;i+=num_threads) {
    	for (int j=i+1;j<dataset.rows;j++) {
	        mat_get_row(&dataset,&row1,i);
	        mat_get_row(&dataset,&row2,j);
	        double dist_sq = vec_dist_sq(&row1,&row2);
	        if (dist_sq > max_dist_sq_thread) {
	        	max_dist_sq_thread = dist_sq;
	        	extreme1_thread = i;
	        	extreme2_thread = j;
	        }
         } 
     }
 } 

    /* stop the timer */
    end_time = omp_get_wtime();

    /* output the results */
#ifdef DEBUG 
    printf ("Number of threads = %d\n",num_threads);
    printf ("Extreme Distance = %lf\n",sqrt(max_dist_sq));
    printf ("Extreme Pair = %d %d\n",extreme1,extreme2);
    printf ("wall time used = %.4f sec\n",(end_time-start_time));
#else
    printf ("(%d,%.4f),",num_threads,(end_time-start_time));
#endif

    /* free the dataset */
    mat_free(&dataset);

    return 0;
}
