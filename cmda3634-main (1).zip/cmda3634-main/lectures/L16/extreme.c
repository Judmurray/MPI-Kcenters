#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "mat.h"

int main (int argc, char** argv) {

    mat_type dataset;
    int rows, cols;

    /* read the shape of the matrix from STDIN */
    if (scanf("%d %d",&rows,&cols) != 2) {
	printf ("error reading the shape of the matrix\n");
	return 1;
    }

    /* allocate memory for the (rows x cols) dataset */
    mat_malloc (&dataset,rows,cols);

    /* read the dataset from STDIN */
    mat_read (&dataset);

    double max_dist_sq = 0;
    int extreme1, extreme2;
    vec_type row1, row2;
    for (int i=0;i<dataset.rows-1;i++) {
        for (int j=i+1;j<dataset.rows;j++) {
	    mat_get_row(&dataset,&row1,i);
	    mat_get_row(&dataset,&row2,j);
            double dist_sq = vec_dist_sq(&row1,&row2);
            if (dist_sq > max_dist_sq) {
                max_dist_sq = dist_sq;
                extreme1 = i;
                extreme2 = j;
            }
        }
    }

    /* output the results */
    printf ("Extreme Distance = %lf\n",sqrt(max_dist_sq));
    printf ("Extreme Pair = %d %d\n",extreme1,extreme2);

    /* free the dataset */
    mat_free(&dataset);

    return 0;
}
