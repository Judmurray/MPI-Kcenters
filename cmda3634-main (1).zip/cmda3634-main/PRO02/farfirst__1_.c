#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include "mat.h"
#include "vec.h"

double cost(mat_type *dataset, int *centers, int i, int *argmax);

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        printf("Command usage : %s %s\n", argv[0], "k");
        return 1;
    }

    int k = atoi(argv[1]);

    int columns;
    int rows;

    scanf("%d%d", &rows, &columns);

    struct mat_s PMatrix;
    mat_calloc(&PMatrix, rows, columns);
    mat_read(&PMatrix);

    struct mat_s CMatrix;
    mat_calloc(&CMatrix, k, columns);

    for (int i = 0; i < columns; i++)
    {
        CMatrix.data[i] = PMatrix.data[i];
    }

    int *centers;
    centers = (int *)calloc(k, sizeof(int));

    centers[0] = 0;

    int indexResult = 0;

    for (int i = 1; i < k; i++)
    {
        double calculatedCost = cost(&PMatrix, centers, i, &indexResult);

        centers[i] = indexResult;
        for (int u = 0; u < columns; u++)
        {
            CMatrix.data[u + (i * columns)] = PMatrix.data[(indexResult * columns) + u];
        }
    }

    double optimalCost = cost(&PMatrix, centers, k, &indexResult);

    printf("# approximate optimal cost = %.2lf\n", optimalCost);
    printf("# approx optimal centers :\n");
    mat_print(&CMatrix);

    return 0;
}

double cost(mat_type *dataset, int *centers, int i, int *argmax)
{

    double maximum = -DBL_MAX;

    int maxIndex;
    for (int j = 0; j < dataset->rows; j++)
    {
        double minimumCost = DBL_MAX;
        struct vec_s currentVector;
        vec_calloc(&currentVector, dataset->cols);

        mat_get_row(dataset, &currentVector, j);

        for (int index = 0; index < i; index++)
        {

            struct vec_s compareVector;
            vec_calloc(&compareVector, dataset->cols);

            mat_get_row(dataset, &compareVector, centers[index]);

            double currentDistance = vec_dist_sq(&currentVector, &compareVector);
            if (currentDistance < minimumCost)
            {
                minimumCost = currentDistance;
            }
        }

        if (minimumCost > maximum)
        {
            maximum = minimumCost;
            maxIndex = j;
        }
    }

    *argmax = maxIndex;

    return maximum;
}