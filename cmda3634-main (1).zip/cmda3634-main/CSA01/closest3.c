#include <stdio.h>
#include <stdlib.h>
#include <float.h>

int main (int argc, char** argv) {
    if (argc < 2) {
        printf ("Command usage : %s %s\n",argv[0],"center");
        return 1;
    }
    double center = atof(argv[1]);
    double number;
    double closest = DBL_MAX;
    double secClosest = DBL_MAX;
    double thClosest = DBL_MAX;
    double min_distance_sq = DBL_MAX;
    double distance_sq2 = DBL_MAX;
    double distance_sq3 = DBL_MAX;
    int num_read = 0;
    while (scanf("%lf",&number) == 1) {
        double distance_sq = (center-number)*(center-number);
                if((distance_sq < min_distance_sq)&&(distance_sq < distance_sq2)&&(distance_sq < distance_sq3)) { 
                    closest = number;
                   min_distance_sq = distance_sq; 
                }
                if((distance_sq < distance_sq2)&&(distance_sq < distance_sq3)&&(distance_sq > min_distance_sq))
                {
                 secClosest = number; 
                 distance_sq2 = distance_sq;
                }
                if ((distance_sq > distance_sq2)&&(distance_sq < distance_sq3)&&(distance_sq > min_distance_sq)) { 
                 thClosest = number;
                distance_sq3 = distance_sq; 
                
                }
           
        
	num_read++;
    }
    if (num_read > 0) {
	printf ("The number closest to %lf is %lf\n",center,closest);
    printf ("The number second closest is %lf\n",secClosest);
    printf ("The number third closest is %lf\n",thClosest);
    }
    return 0;
}

