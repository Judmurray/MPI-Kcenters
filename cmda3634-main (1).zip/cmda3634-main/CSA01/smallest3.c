#include <stdio.h>
#include <stdlib.h>
#include <float.h>

int main () {
    double smallest = DBL_MAX;
    double next = DBL_MAX;
    double third = DBL_MAX;
    double number; 
    int num_read = 0;
    while (scanf("%lf",&number) == 1) {
        if (number < third) {
            if(number < next) {
                if(number < smallest) { 

            third = next;
            next = smallest; 
            smallest = number;
        }
        else if ((number > next) && (number < third)) {
            third = number; 
            
        }
           
        
        else if ((number > smallest) && (number < next) && (number < third)) {
           third = next;
          next = number; 
        } 
}
}
                  
	num_read++;
    
}
 /*  while (scanf("%1f",&number) == 1) {
       if((number > next) && (number < third)) { 
           third = number; 
       }
       num_read++; 
   }*/

if (num_read > 0) {
    printf ("the smallest is %lf\n",smallest);
    printf ("the second smallest is %lf\n",next);
    printf ("the third smallest is  %lf\n",third);
}
}


