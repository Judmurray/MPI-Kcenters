#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

struct point {
    double distance;
    int index;
};


int main (int argc, char** argv) {
    if (argc < 4) {
        printf("Command usage : %s %c %c %c",argv[0],'k','x', 'y');
        return 1;
    }
    int k = atoi(argv[1]);
    double x = atof(argv[2]);
    double y = atof(argv[3]);
    
  //  double min_distance_sq = DBL_MAX; 


    struct point *values;
    values = malloc(k * sizeof(struct point));
    
   double xfile; 
   double yfile; 
   int count = 0;

    while(scanf("%lf %lf",&xfile, &yfile) == 2) { 
        double distance = sqrt((xfile-x)*(xfile-x) + (yfile-y)*(yfile-y));
        if (count < k) { 
           
            values[count].distance = distance;
            values[count].index = count;
          
        } 
        else  {
            int index = 0; 
            double max_diff = values[0].distance;
            int i;
            for( i  =1; i < k; i++) { 
                double curr_diff = values[i].distance; 
                if(max_diff < curr_diff) { 
                    max_diff = curr_diff; 
                    index = i; 
                } 
            }
           
            if( distance < max_diff) { 
                values[index].distance = distance; 
                 values[index].index = count; 
            }
        }
          count++;
    
}
     int i;
     int j;
  for( i = 0; i < k - 1; i++) { 
        for( j = 0; j < k - i - 1; j++) {
           double distance1 = values[j].distance;
           double distance2 = values[j+1].distance;   
            if(distance1 > distance2) { 
                double temp1 = values[j].distance;
                int temp2 = values[j].index;

                values[j].distance = values[j+1].distance; 
                 values[j].index = values[j+1].index;                 
             
                values[j+1].distance = temp1; 
                values[j+1].index = temp2; 
            }
        }
    }

int u;
   for(u = 0; u < k; u++) { 
       printf("%d",values[u].index);
        printf(" %lf\n",values[u].distance);
      
    }
    return 0;
}
