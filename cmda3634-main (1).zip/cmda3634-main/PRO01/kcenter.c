#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <time.h>

int main (int argc, char** argv) {

    /* get k, m, and optionally s from the command line */
    if (argc < 3) {
	printf ("Command usage : %s %s %s %s\n",argv[0],"k","m","(s)");
	return 1;
    }

    int k = atoi(argv[1]);
    int m = atoi(argv[2]);

    /* seed the random number generator */
    if (argc > 3) {
	srandom(atoi(argv[3]));
    } else {
	srand(time(NULL));  
    }

    /* generate m random k-tuples selected from n cities */
    int n = 120;
    int tuple[k];
    for (int i=0;i<m;i++) {
	for (int j=0;j<k;j++) {
	    tuple[j] = random() % n;
	}
	/* print out the random k-tuple (remove later) */
	for (int j=0;j<k;j++) {
	    printf ("%d ",tuple[j]);
	}
	printf ("\n");
    }

    return 0;

}
