#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

struct point {
    double x;
    double y;
};


int main (int argc, char** argv) {
    if (argc < 1) {
        printf("Command usage : %s",argv[0]);
        return 1;
    }
  
    
    double min_cost = DBL_MAX; 

    struct point *values;
    values = calloc(2000,  sizeof(struct point));

    int size = 0;
    double xfile; 
   double yfile; 

   int tuples = 0;
   int c1 =0;
   int c2=0;

   int c3=0;

    while(scanf("%lf %lf",&xfile, &yfile) == 2) {
        values[size].x = xfile;
        values[size].y = yfile; 
        size++;
      
}



    values = realloc(values,size* sizeof(struct point));

    for(int i = 0; i < size-2; i++) { 

        for(int j = i+1; j < size-1; j++) { 


            for(int k = j+1; k < size; k++) { 

                double cost =0;
                tuples++;
                for(int m = 0; m < size; m++) { 

                    double iDistance = (values[m].x - values[i].x)* (values[m].x - values[i].x) +  (values[m].y - values[i].y)* (values[m].y - values[i].y);

                    double jDistance = (values[m].x - values[j].x)* (values[m].x - values[j].x) +  (values[m].y - values[j].y)* (values[m].y - values[j].y);

                    double kDistance = (values[m].x - values[k].x)* (values[m].x - values[k].x) +  (values[m].y - values[k].y)* (values[m].y - values[k].y);

                    double min_dist_sq;


                    if(iDistance<jDistance && iDistance<kDistance){
                        min_dist_sq = iDistance;
                    }
                    else if(jDistance<iDistance && jDistance<kDistance){
                        min_dist_sq = jDistance;
                    }
                    else{
                        min_dist_sq = kDistance;
                    }

                    if(min_dist_sq>cost){
                        cost = min_dist_sq;
                    } 

                }

                 if(cost<min_cost){
                        min_cost = cost;
                        c1=i;
                        c2=j;
                        c3=k;
                    }





            }



        }


    }




     printf("number of 3-tuples checked = %d\n", tuples);
     printf("minimal cost = %lf\n", min_cost);
     printf("optimal centers : %d %d %d\n", c1, c2, c3);




    return 0;
}