#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

struct point {
    double x;
    double y;
};


int main (int argc, char** argv) {
    if (argc < 1) {
        printf("Command usage : %s",argv[0]);
        return 1;
    }
  
    
    double min_cost = DBL_MAX; 

    struct point *values;
    values = calloc(2000,  sizeof(struct point));

    int size = 0;
    double xfile; 
   double yfile; 

   int tuples = 0;
   int c1 =0;
   int c2=0;
   int c3=0;
   int c4=0;

    while(scanf("%lf %lf",&xfile, &yfile) == 2) {
        values[size].x = xfile;
        values[size].y = yfile; 
        size++;
      
}



    values = realloc(values,size* sizeof(struct point));

    for(int i = 0; i < size-3; i++) { 

        for(int j = i+1; j < size-2; j++) { 


            for(int k = j+1; k < size - 1; k++) { 
                
                for(int s = k+1; s <size; s++) { 


                double cost =0;
                tuples++;
                for(int m = 0; m < size; m++) { 

                    double iDistance = (values[m].x - values[i].x)* (values[m].x - values[i].x) +  (values[m].y - values[i].y)* (values[m].y - values[i].y);

                    double jDistance = (values[m].x - values[j].x)* (values[m].x - values[j].x) +  (values[m].y - values[j].y)* (values[m].y - values[j].y);

                    double kDistance = (values[m].x - values[k].x)* (values[m].x - values[k].x) +  (values[m].y - values[k].y)* (values[m].y - values[k].y);

                    double sDistance = (values[m].x - values[s].x)* (values[m].x - values[s].x) +  (values[m].y - values[s].y)* (values[m].y - values[s].y);      

                    double min_dist_sq;


                    if(iDistance<jDistance && iDistance<kDistance && iDistance < sDistance){
                        min_dist_sq = iDistance;
                    }
                    else if(jDistance<iDistance && jDistance<kDistance && jDistance < sDistance){
                        min_dist_sq = jDistance;
                    }
                    else if ( kDistance < iDistance && kDistance < jDistance && kDistance < sDistance) 
                    { 
                        min_dist_sq = kDistance;
                    }
                    else { 
                        min_dist_sq = sDistance; 
                    }

                    if(min_dist_sq>cost){
                        cost = min_dist_sq;
                    } 

                }

                 if(cost<min_cost){
                        min_cost = cost;
                        c1=i;
                        c2=j;
                        c3=k;
                        c4=s; 
                    }





            }



        }


    }

    }


     printf("number of 4-tuples checked = %d\n", tuples);
     printf("minimal cost = %lf\n", min_cost);
     printf("optimal centers : %d %d %d %d\n ", c1, c2, c3, c4);




    return 0;
}
