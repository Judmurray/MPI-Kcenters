#include <stdio.h>
#include <stdlib.h>
#include <float.h>

int main (int argc, char** argv) {
    if (argc < 3) {
        printf ("Command usage : %s %s %s\n",argv[0],"k","center");
        return 1;
    }
    int k = atoi(argv[1]);
    double center = atof(argv[2]);
    double number; 
  //  double min_distance_sq = DBL_MAX; 
    double *values;
    values = malloc(k*sizeof(double));
   int count = 0;  
    while(scanf("%lf",&number) == 1) { 
        if (count < k) { 
            values[count] = number;
            count++;
        } 
        else  {
            int index = 0; 
            double max_diff = (values[0] - center)*(values[0] - center); 
            for(int i  =1; i < k; i++) { 
                double curr_diff = (values[i] - center)*(values[i] - center); 
                if(max_diff < curr_diff) { 
                    max_diff = curr_diff; 
                    index = i; 
                } 
            }
            double num_diff = (number - center)*(number - center); 
            if( num_diff < max_diff) { 
                values[index] = number; 
            }
        }
    }
    for(int i = 0; i < k - 1; i++) { 
        for(int j = 0; j < k - i - 1; j++) {
           double diff = (values[j] - center)*(values[j] - center);  
           double diff2 = (values[j+1] - center)*(values[j+1] - center); 
            if(diff > diff2) { 
                double temp = values[j];
                values[j] = values[j+1]; 
                values[j+1] = temp; 
            }
        }
    }
    for(int i = 0; i < k; i++) { 
        printf("%lf\n",values[i]);
    }
    return 0;
}
