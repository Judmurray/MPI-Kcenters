#include <stdio.h>
#include <stdlib.h>
#include <float.h>

int main (int argc, char** argv) {
    
    if (argc < 2) {
        printf ("Command usage : %s %s\n",argv[0],"k");
        return 1;
    }
 
    int k = atoi(argv[1]);

    double number;
    double *values;
    values = malloc(k*sizeof(double));
    int count = 0; 
    while(scanf("%lf",&number) == 1) {        
        if(count < k) { 
            values[count] = number; 
            count++; 
        }
        else { 
            int index = 0; 
            double biggest = values[0]; 
           for(int i = 1; i < k; i++) {
              if(biggest < values[i]) {
                  biggest = values[i]; 
                  index = i; 
              } 
           } 
           if(number < biggest) { 
               values[index] = number; 
           } 
        } 
    }
    for(int i = 0; i < k -1; i++) { 
        for ( int j = 0; j < k -i -1; j++){
            if(values[j] > values[j+1]){
                double temp = values[j];
                values[j] = values[j+1];
                values[j+1] = temp;
            }
        }
    }
    int Digs = DECIMAL_DIG; 

    for(int i = 0; i < k; i++) { 
        printf ("%lf\n",values[i]);
    } 


return 0; 

}

